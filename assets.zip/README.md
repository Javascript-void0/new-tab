# Web Browser Startup Page

![screenshot](assets/screenshot.png)