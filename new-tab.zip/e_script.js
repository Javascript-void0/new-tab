setInterval(function() {
    width = window.innerWidth
    height = window.innerHeight
    if (width > height && currLargest != '100vh') {
        root.style.setProperty('--largest', '100vh')
        currLargest = '100vh'
    } else if (height > width && currLargest != '100vw') {
        root.style.setProperty('--largest', '100vw')
        currLargest = '100vw'
    }
})

cardTemplate = `
<div class="card">
    <div class="outline">
        <div class="content">

        </div>
    </div>
</div>  
`

cardsJSON = `
{
    "cards": [
        {
            "href": "https://github.com",
            "text": "github"
        },
        {
            "href": "https://anilist.co",
            "text": "anilist"
        },
        {
            "href": "https://youtube.com",
            "text": "youtube"
        },
        {
            "href": "https://schoology.tesd.net",
            "text": "schoology"
        },
        {
            "href": "https://youtube.com",
            "text": "youtube"
        },
        {
            "href": "https://youtube.com",
            "text": "youtube"
        },
        {
            "href": "https://music.youtube.com/channel/UCR09QSwRp9TGLBvMBmpKbRw",
            "text": "yt-music"
        },
        {
            "href": "https://www.last.fm/user/v-lucent",
            "text": "lastfm"
        },
        {
            "href": "https://youtube.com",
            "text": "youtube"
        },
        {
            "href": "https://youtube.com",
            "text": "youtube"
        },
        {
            "href": "https://youtube.com",
            "text": "youtube"
        },
        {
            "href": "https://youtube.com",
            "text": "youtube"
        },
        {
            "href": "https://youtube.com",
            "text": "youtube"
        },
        {
            "href": "https://youtube.com",
            "text": "youtube"
        },
        {
            "href": "https://youtube.com",
            "text": "youtube"
        },
        {
            "href": "https://javascript-void0.github.io",
            "text": "website"
        }
    ]
}
`

grid = document.getElementById('grid')
root = document.querySelector(':root')
currLargest = getComputedStyle(root).getPropertyValue('--largest')
cards = JSON.parse(cardsJSON)

for (i = 0; i < 16; i++) {
    a = document.createElement('a')
    a.classList.add('link')
    a.href = cards["cards"][i]["href"]
    a.innerHTML = cardTemplate.replace('CONTENT', cards["cards"][i]["text"])
    
    content = a.children[0].children[0].children[0]

    container = document.createElement('div')
    container.classList.add('container')

    icon = document.createElement('div')
    icon.classList.add("icon")
    icon.id = cards["cards"][i]["text"]
    icon.textContent = "a"
    container.appendChild(icon)

    label = document.createElement('div')
    label.classList.add('label')
    label.textContent = cards["cards"][i]["text"]
    container.appendChild(label)

    content.appendChild(container)

    grid.appendChild(a)
}
